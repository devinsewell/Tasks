//
//  ViewController.m
//  tasks
//
//  Created by devin sewell on 5/29/14.
//  Copyright (c) 2014 KEOIS. All rights reserved.
//

#import "ViewController.h"
#import "CellRecip.h"

@interface ViewController ()

@end

@implementation ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    tasks = [[NSMutableArray alloc] init];
    tasksCompleted = [[NSMutableArray alloc] init];
    defaults = [NSUserDefaults standardUserDefaults];
    if([defaults objectForKey:@"tasks"]){
        tasks = [defaults objectForKey:@"tasks"];
    }
    if([defaults objectForKey:@"tasksCompleted"]){
        tasksCompleted = [defaults objectForKey:@"tasksCompleted"];
    }
    table = [[UITableView alloc] initWithFrame:CGRectMake(0, 11+44+44, self.view.frame.size.width, self.view.frame.size.height-88-20)];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview:table];
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 20+44+44+12)];
    header.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:header];
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, 320, 44)];
    title.text = @"Tasks";
    title.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:title];
    addTask = [[UITextField alloc] initWithFrame:CGRectMake(10, 20+44, self.view.frame.size.width-20, 44)];
    addTask.borderStyle = UITextBorderStyleRoundedRect;
    addTask.delegate = self;
    addTask.placeholder = @"Add a task...";
    [self.view addSubview:addTask];
    
}
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [addTask resignFirstResponder];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self addTask];
    return YES;
}

-(void)addTask{
    NSMutableDictionary *task = [[NSMutableDictionary alloc] initWithObjectsAndKeys:addTask.text, @"title",@"0", @"completed", nil];
    [tasks addObject:task];
    [defaults setObject:tasks forKey:@"tasks"];
    [defaults synchronize];
    [table reloadData];
    [addTask resignFirstResponder];
    addTask.text = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section==0){
        return [tasks count];
    }
    if(section==1){
        return [tasksCompleted count];
    }
    return 0;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if(section == 0){
        return @"to do";
    }
    if(section == 1){
        return @"completed";
    }
    return nil;
}
// Swipe to delete.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        if(indexPath.section==0){
            [tasks removeObjectAtIndex:indexPath.row];
        }else{
            [tasksCompleted removeObjectAtIndex:indexPath.row];
        }
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return YES if you want the specified item to be editable.
    return YES;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  
    static NSString *cellId = @"cell";
    CellRecip *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    cell.backgroundColor = [UIColor whiteColor];
    if (cell == nil) {
        cell = [[CellRecip alloc] initWithFrame:CGRectZero reuseIdentifier:cellId];
    }
    if(indexPath.section==0){
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.userName.text = [[tasks objectAtIndex:indexPath.row] objectForKey:@"title"];
    }else{
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        cell.userName.text = [[tasksCompleted objectAtIndex:indexPath.row] objectForKey:@"title"];

    }
    return cell;
    
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    CellRecip *cell = [tableView cellForRowAtIndexPath:indexPath];
    if(cell.accessoryType==UITableViewCellAccessoryNone){
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        [tasksCompleted addObject:[tasks objectAtIndex:indexPath.row]];
        NSMutableArray *newTasks = [[NSMutableArray alloc]init];
        for(NSDictionary *d in tasks){
            if(![[d objectForKey:@"title"]isEqualToString:[[tasks objectAtIndex:indexPath.row] objectForKey:@"title"]]){
                [newTasks addObject:d];
                NSLog([d objectForKey:@"title"]);
            }
        }
        NSLog(@"%@",newTasks);
        tasks = newTasks;
        NSLog(@"%1d",[tasks count]);
    }else{
        cell.accessoryType = UITableViewCellAccessoryNone;
        [tasks addObject:[tasksCompleted objectAtIndex:indexPath.row]];
        NSMutableArray *newTasksCompleted = [[NSMutableArray alloc]init];
        for(NSDictionary *d in tasksCompleted){
            if(![[d objectForKey:@"title"]isEqualToString:[[tasksCompleted objectAtIndex:indexPath.row] objectForKey:@"title"]]){
                [newTasksCompleted addObject:d];
            }
        }
        NSLog(@"%@",newTasksCompleted);
        tasksCompleted = newTasksCompleted;
    }
    [defaults setObject:tasks forKey:@"tasks"];
    [defaults setObject:tasksCompleted forKey:@"tasksCompleted"];
    [defaults synchronize];
    [table reloadData];
    //[tableView deselectRowAtIndexPath:indexPath animated:YES];
}


@end
