//
//  CellRecip.h
//  unsayapp
//
//  Created by devin sewell on 1/12/14.
//  Copyright (c) 2014 unsayapp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellRecip : UITableViewCell{
    UILabel *userName;
    UILabel *picLetter;
}
@property(nonatomic,retain)UILabel *userName;
@property(nonatomic,retain)UILabel *picLetter;

@end
