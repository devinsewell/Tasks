//
//  Cell.h
//  unsayapp
//
//  Created by devin sewell on 1/12/14.
//  Copyright (c) 2014 unsayapp LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Cell : UITableViewCell{
    UILabel *userName;
    UILabel *letter;
    UILabel *subLabel;
    UIView *logo;
    UILabel *time;
    UILabel *expires;
    UIView *icon1;
    UIView *icon2;
    UIView *circle;
}
@property(nonatomic,retain)UILabel *userName;
@property(nonatomic,retain)UILabel *letter;
@property(nonatomic,retain)UILabel *subLabel;
@property(nonatomic,retain)UIView *logo;
@property(nonatomic,retain) UILabel *time;
@property(nonatomic,retain) UILabel *expires;
@property(nonatomic,retain) UIView *icon1;
@property(nonatomic,retain) UIView *icon2;
@property(nonatomic,retain) UIView *circle;

@end
