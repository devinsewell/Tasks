//
//  Cell.m
//  unsayapp
//
//  Created by devin sewell on 1/12/14.
//  Copyright (c) 2014 unsayapp LLC. All rights reserved.
//

#import "Cell.h"

@implementation Cell

@synthesize userName, letter, subLabel, logo, circle, icon1, icon2;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) {
        // Initialization code
        userName = [[UILabel alloc]initWithFrame:CGRectMake(70 ,9, 200, 25)];
        userName.textAlignment = UITextAlignmentLeft;
        userName.font = [UIFont fontWithName:@"HelveticaNeue-Light" size:16];
        
        circle = [[UIView alloc] initWithFrame:CGRectMake(13 ,12, 42, 42)];
        circle.backgroundColor = [UIColor colorWithRed:73.0/255.0 green:134.0/255.0 blue:144.0/255.0 alpha:1.0];
        circle.layer.cornerRadius = 21.0;
        [self.contentView addSubview:circle];
        
        letter = [[UILabel alloc]initWithFrame:CGRectMake(13 ,10, 42, 42)];
        letter.font = [UIFont fontWithName:@"HelveticaNeue-UltraLight" size:26];
        letter.textColor = [UIColor whiteColor];
        letter.textAlignment = NSTextAlignmentCenter;
        letter.backgroundColor = [UIColor clearColor];
        
        logo = [[UIView alloc] initWithFrame:CGRectMake(0, 8, 42, 24)];
        logo.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"logoHeader"]];
        CGAffineTransform tr = CGAffineTransformScale(logo.transform, 0.6, 0.6);
        logo.transform = tr;
        [circle addSubview:logo];
        
        subLabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 32, 100, 20)];
        subLabel.font = [UIFont fontWithName:@"HelveticaNeue-Light" size:14];
        subLabel.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:subLabel];
        
        
        [self.contentView addSubview:userName];
        [self.contentView addSubview:letter];
        
        
        time = [[UILabel alloc] init];
        [self addSubview:time];
        expires = [[UILabel alloc] init];
        [self addSubview:expires];
        
        
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect contentRect = self.contentView.bounds;
    
    
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
