//
//  CellRecip.m
//  unsayapp
//
//  Created by devin sewell on 1/12/14.
//  Copyright (c) 2014 unsayapp LLC. All rights reserved.
//

#import "CellRecip.h"

@implementation CellRecip

@synthesize userName, picLetter;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) {
        // Initialization code
        userName = [[UILabel alloc]initWithFrame:CGRectMake(10, 12, 300, 30)];
        userName.font = [UIFont fontWithName:@"HelveticaNeue-Light" size:16];
        userName.textAlignment = UITextAlignmentLeft;
               [self.contentView addSubview:userName];
        
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    picLetter.frame = CGRectMake(10, 10, 36.0, 36.0);

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
