//
//  ViewController.h
//  tasks
//
//  Created by devin sewell on 5/29/14.
//  Copyright (c) 2014 KEOIS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>{
    UITableView *table;
    NSMutableArray *tasks;
    NSMutableArray *tasksCompleted;
    UITextField *addTask;
    NSUserDefaults *defaults;
}

@end
